"""
Обработчики — текст, фото, альбомы, документы-картинки.
"""

import asyncio
from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from aiogram.enums import ParseMode, ChatAction

import gemini_service

router = Router()

# ─── Буфер для альбомов ───
# Telegram присылает каждое фото альбома отдельным сообщением
# с одинаковым media_group_id. Собираем их вместе.
_album_buf: dict[str, list[Message]] = {}
_album_locks: dict[str, asyncio.Lock] = {}


# ═══════════════════════════════════════
#               КОМАНДЫ
# ═══════════════════════════════════════

@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    text = (
        "👋 <b>Привет! Я решаю домашние задания!</b>\n\n"
        "📌 <b>Что я умею:</b>\n"
        "• Решаю задачи по любым предметам\n"
        "• Читаю задания с фотографий 📸\n"
        "• Принимаю несколько фото сразу (альбом)\n"
        "• Помню контекст разговора\n\n"
        "📷 <b>Как отправить фото:</b>\n"
        "1. Сфотографируй задание\n"
        "2. Отправь фото мне (можно несколько)\n"
        "3. Можешь добавить подпись к фото\n"
        "4. Получи решение!\n\n"
        "✏️ Или просто напиши задание текстом\n\n"
        "⚡ /clear — очистить историю\n"
        "❓ /help — помощь"
    )
    await message.answer(text, parse_mode=ParseMode.HTML)


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    text = (
        "📖 <b>Как пользоваться</b>\n\n"
        "📝 <b>Текст:</b> просто напиши задание\n"
        "  <i>Пример: Реши 2x² - 8 = 0</i>\n\n"
        "📷 <b>Одно фото:</b> сфотографируй и отправь\n"
        "  Можно добавить подпись: «реши номер 5»\n\n"
        "🖼 <b>Несколько фото:</b> выбери несколько\n"
        "  фото и отправь альбомом — прочитаю все\n\n"
        "📎 <b>Файл-картинка:</b> тоже принимаю\n\n"
        "💬 <b>Уточнения:</b> после ответа можешь\n"
        "  спросить «объясни шаг 2 подробнее»\n\n"
        "🔄 /clear — сбросить контекст диалога"
    )
    await message.answer(text, parse_mode=ParseMode.HTML)


@router.message(Command("clear"))
async def cmd_clear(message: Message) -> None:
    gemini_service.clear_history(message.from_user.id)
    await message.answer("🗑 История очищена. Задавай новый вопрос!")


@router.message(Command("solve"))
async def cmd_solve(message: Message) -> None:
    task = message.text.replace("/solve", "", 1).strip()
    if not task:
        await message.answer(
            "Напиши задание после команды:\n"
            "<code>/solve Реши x² - 9 = 0</code>",
            parse_mode=ParseMode.HTML,
        )
        return
    await message.bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    answer = await gemini_service.ask_text(message.from_user.id, task)
    await _send(message, answer)


# ═══════════════════════════════════════
#          ФОТО (одиночное + альбом)
# ═══════════════════════════════════════

@router.message(F.photo)
async def handle_photo(message: Message, bot: Bot) -> None:
    """Принимает фото — одиночное или часть альбома."""

    # ─── Альбом (media_group) ───
    if message.media_group_id:
        await _collect_album(message, bot)
        return

    # ─── Одиночное фото ───
    await bot.send_chat_action(message.chat.id, ChatAction.TYPING)

    photo_bytes = await _download_photo(message, bot)
    if not photo_bytes:
        await message.answer("⚠️ Не удалось скачать фото. Попробуй ещё раз.")
        return

    caption = message.caption or ""

    await bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    answer = await gemini_service.ask_photo(
        message.from_user.id, photo_bytes, caption
    )
    await _send(message, answer)


# ═══════════════════════════════════════
#          ДОКУМЕНТЫ (картинки файлом)
# ═══════════════════════════════════════

@router.message(F.document)
async def handle_document(message: Message, bot: Bot) -> None:
    """Принимает картинки отправленные как документ/файл."""

    mime = message.document.mime_type or ""
    if not mime.startswith("image/"):
        await message.answer(
            "📎 Я принимаю только <b>фото</b> или <b>текст</b> с заданием.",
            parse_mode=ParseMode.HTML,
        )
        return

    await bot.send_chat_action(message.chat.id, ChatAction.TYPING)

    try:
        file = await bot.get_file(message.document.file_id)
        result = await bot.download_file(file.file_path)
        photo_bytes = result.read()
    except Exception:
        await message.answer("⚠️ Не удалось скачать файл.")
        return

    caption = message.caption or ""

    await bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    answer = await gemini_service.ask_photo(
        message.from_user.id, photo_bytes, caption
    )
    await _send(message, answer)


# ═══════════════════════════════════════
#           СТИКЕРЫ / ГОЛОС / ПРОЧЕЕ
# ═══════════════════════════════════════

@router.message(F.sticker | F.voice | F.video | F.video_note | F.animation)
async def handle_unsupported(message: Message) -> None:
    await message.answer(
        "🤔 Я пока не понимаю такой формат.\n\n"
        "Отправь:\n"
        "📷 <b>Фото</b> задания\n"
        "✏️ <b>Текст</b> задания",
        parse_mode=ParseMode.HTML,
    )


# ═══════════════════════════════════════
#           ТЕКСТ (catch-all)
# ═══════════════════════════════════════

@router.message(F.text)
async def handle_text(message: Message) -> None:
    await message.bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    answer = await gemini_service.ask_text(message.from_user.id, message.text)
    await _send(message, answer)


# ═══════════════════════════════════════
#          ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ═══════════════════════════════════════

async def _download_photo(message: Message, bot: Bot) -> bytes | None:
    """Скачать фото из сообщения (макс. разрешение)."""
    try:
        photo = message.photo[-1]  # последнее = самое большое
        file = await bot.get_file(photo.file_id)
        result = await bot.download_file(file.file_path)
        return result.read()
    except Exception:
        return None


async def _collect_album(message: Message, bot: Bot) -> None:
    """
    Собирает фото из альбома.
    Telegram отправляет каждое фото альбома отдельным сообщением.
    Ждём 1.5 сек, потом обрабатываем всё разом.
    """
    group_id = message.media_group_id

    if group_id not in _album_locks:
        _album_locks[group_id] = asyncio.Lock()

    if group_id not in _album_buf:
        _album_buf[group_id] = []

    _album_buf[group_id].append(message)

    # Первое сообщение альбома запускает таймер
    if len(_album_buf[group_id]) == 1:
        await asyncio.sleep(1.5)  # ждём остальные фото альбома
        await _process_album(group_id, bot)


async def _process_album(group_id: str, bot: Bot) -> None:
    """Обработать собранный альбом."""
    messages = _album_buf.pop(group_id, [])
    _album_locks.pop(group_id, None)

    if not messages:
        return

    first_msg = messages[0]
    await bot.send_chat_action(first_msg.chat.id, ChatAction.TYPING)

    # Скачиваем все фото
    photos_bytes: list[bytes] = []
    for msg in messages:
        data = await _download_photo(msg, bot)
        if data:
            photos_bytes.append(data)

    if not photos_bytes:
        await first_msg.answer("⚠️ Не удалось скачать фото из альбома.")
        return

    # Подпись берём из первого фото (только у первого бывает caption)
    caption = ""
    for msg in messages:
        if msg.caption:
            caption = msg.caption
            break

    await bot.send_chat_action(first_msg.chat.id, ChatAction.TYPING)

    # Если одно фото — используем обычный метод
    if len(photos_bytes) == 1:
        answer = await gemini_service.ask_photo(
            first_msg.from_user.id, photos_bytes[0], caption
        )
    else:
        answer = await gemini_service.ask_multiple_photos(
            first_msg.from_user.id, photos_bytes, caption
        )

    await _send(first_msg, answer)


async def _send(message: Message, text: str) -> None:
    """Отправить ответ, разбивая длинные сообщения."""
    MAX = 4000

    if not text:
        await message.answer("🤔 Не удалось получить ответ. Попробуй ещё раз.")
        return

    if len(text) <= MAX:
        try:
            await message.answer(text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            try:
                await message.answer(text, parse_mode=ParseMode.HTML)
            except Exception:
                await message.answer(text)
        return

    # Разбиваем длинный текст
    parts: list[str] = []
    while text:
        if len(text) <= MAX:
            parts.append(text)
            break
        pos = text.rfind("\n", 0, MAX)
        if pos == -1:
            pos = text.rfind(". ", 0, MAX)
        if pos == -1:
            pos = MAX
        parts.append(text[:pos])
        text = text[pos:].lstrip("\n")

    for i, part in enumerate(parts):
        header = f"📄 Часть {i+1}/{len(parts)}\n\n" if len(parts) > 1 else ""
        try:
            await message.answer(header + part, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await message.answer(header + part)