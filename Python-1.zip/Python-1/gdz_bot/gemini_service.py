import base64
from groq import AsyncGroq
from config import GROQ_API_KEY, SYSTEM_PROMPT

client = AsyncGroq(api_key=GROQ_API_KEY)

TEXT_MODEL = "llama-3.3-70b-versatile"
VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"

_history: dict[int, list[dict]] = {}


def _get_history(user_id: int) -> list[dict]:
    if user_id not in _history:
        _history[user_id] = []
    return _history[user_id]


def clear_history(user_id: int) -> None:
    _history.pop(user_id, None)


async def ask_text(user_id: int, question: str) -> str:
    try:
        history = _get_history(user_id)
        history.append({"role": "user", "content": question})

        if len(history) > 20:
            _history[user_id] = history[-20:]
            history = _history[user_id]

        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history

        response = await client.chat.completions.create(
            model=TEXT_MODEL,
            messages=messages,
            temperature=0.3,
            max_tokens=4096,
        )

        answer = response.choices[0].message.content
        history.append({"role": "assistant", "content": answer})
        return answer

    except Exception as e:
        return f"❌ Ошибка: {e}"


async def ask_photo(user_id: int, photo_bytes: bytes, caption: str = "") -> str:
    try:
        b64 = base64.b64encode(photo_bytes).decode("utf-8")

        prompt = caption if caption else (
            "Внимательно рассмотри фото. "
            "Прочитай весь текст, числа, формулы. "
            "Реши задание пошагово и дай ответ."
        )

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{b64}"
                        },
                    },
                ],
            },
        ]

        response = await client.chat.completions.create(
            model=VISION_MODEL,
            messages=messages,
            temperature=0.3,
            max_tokens=4096,
        )

        answer = response.choices[0].message.content

        history = _get_history(user_id)
        history.append({"role": "user", "content": f"[фото] {prompt}"})
        history.append({"role": "assistant", "content": answer})

        return answer

    except Exception as e:
        return f"❌ Ошибка обработки фото: {e}"


async def ask_multiple_photos(user_id: int, photos_bytes: list[bytes], caption: str = "") -> str:
    try:
        prompt = caption if caption else (
            f"Тебе отправили {len(photos_bytes)} фото. "
            "Рассмотри КАЖДОЕ, прочитай текст. "
            "Реши все задания пошагово."
        )

        content = [{"type": "text", "text": prompt}]

        for photo in photos_bytes:
            b64 = base64.b64encode(photo).decode("utf-8")
            content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{b64}"
                },
            })

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content},
        ]

        response = await client.chat.completions.create(
            model=VISION_MODEL,
            messages=messages,
            temperature=0.3,
            max_tokens=4096,
        )

        answer = response.choices[0].message.content

        history = _get_history(user_id)
        history.append({"role": "user", "content": f"[{len(photos_bytes)} фото] {prompt}"})
        history.append({"role": "assistant", "content": answer})

        return answer

    except Exception as e:
        return f"❌ Ошибка обработки фото: {e}"